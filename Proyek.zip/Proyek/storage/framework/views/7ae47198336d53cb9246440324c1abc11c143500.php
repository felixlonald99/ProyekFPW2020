<style>
    .footer{
        background-color:black;
        color:white;
    }
</style>
<div class="footer">
    <center>Ini adalah footer saya :)</center>
</div><?php /**PATH F:\Kris\Kuliah Infor\Astep\Ganjil 2020\FPW\m1\tutor\tutor1\resources\views/includes/footer.blade.php ENDPATH**/ ?>