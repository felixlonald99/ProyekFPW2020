
<?php $__env->startSection('content'); ?>
    <?php if(isset($angka)): ?>
    <h4><?php echo e($angka); ?></h4>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kris\Kuliah Infor\Astep\Ganjil 2020\FPW\m1\tutor\tutor1\resources\views/components/body2.blade.php ENDPATH**/ ?>