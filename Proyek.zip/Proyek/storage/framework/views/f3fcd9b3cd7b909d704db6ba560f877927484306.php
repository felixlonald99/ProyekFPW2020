<style>
    .footer{
        background-color:lightskyblue ;
        color:black;
    }
</style>
<div class="footer">
    <center>© FPW 2020<br>217116594</center>
</div>
<?php /**PATH D:\Materi Kuliah\Framework Pemrograman Web\Praktikum\Minggu 1\Tugas\resources\views/includes/footer.blade.php ENDPATH**/ ?>