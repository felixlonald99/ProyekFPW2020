<?php $__env->startSection('content'); ?>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&family=Roboto:wght@500&display=swap" rel="stylesheet">

<style>
    #boxHotel{
        width: 1050px;
        height: 330px;
        border: 2px solid #ccc;
        margin-bottom: 50px;
        -webkit-transition: 0.5s ease;
    }
        #derawanAdventures{
            position:absolute;
            width: 100%;
            top:30%;
            left:42%;
            font-size:40px;
            font-weight:bold;
            cursor: pointer;
            -webkit-transition: 0.5s ease;
        }
        input[type=text], select {
            width: 100%;
            padding: 10px 10px;
            border: 2px solid #ccc;
            border-radius: 4px;
            font-size:18px;
            opacity: 1;
        }
        input[type=number], select {
            width: 100%;
            padding: 10px 10px;
            border: 2px solid #ccc;
            border-radius: 4px;
            font-size:18px;
            opacity: 1;
        }
        input[type=password], select {
            width: 100%;
            padding: 10px 10px;
            border: 2px solid #ccc;
            border-radius: 4px;
            font-size:18px;
        }
        input[type=submit] {
            width: 100%;
            background-color: tomato;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size:20px;
            transition:0.5s;
        }
        input:hover[type=submit]{
            cursor:pointer;
            background-color: green;
        }
        #fullnameInput{
            position:absolute;
            left:41.5%;
            top:60%;
        }
        #mobileNumberInput{
            position:absolute;
            left:41.5%;
            top:70%;
        }
        #emailInput{
            position:absolute;
            left:41.5%;
            top:80%;
        }
        #usernameInput{
            position:absolute;
            left:41.5%;
            top:90%;
        }
        #passwordInput{
            position:absolute;
            left:41.5%;
            top:100%;
        }
        #confirmPasswordInput{
            position:absolute;
            left:41.5%;
            top:110%;
        }
        #btnRegister{
            position:absolute;
            left:48%;
            top:92%;
        }
        #loginText{
            position:absolute;
            left:33%;
            top:92%;
            font-size:20px;
        }
        .errors{
            position:absolute;
            top:5%;
            left:5%;
        }
</style>

<div class="container" style="margin-top:150px;margin-left:130px;">
    <div id="boxHotel">
        <div id="derawanAdventures">
            Form Booking
        </div>
        <div id="fullnameInput">
            <input type="text" name="fullname" placeholder="Full Name" required pattern="[A-Za-z]{3,30}" title="Must contain alphabet only and at least 3-30 characters">
        </div>

        <div id="mobileNumberInput">
            <input type="text" name="mobileNumber" placeholder="Mobile Number" required pattern="[0-9]{10,12}" title="Must contain number only and at least 10-12 characters">
        </div>

        <div id="emailInput">
            <input type="number" name="email" placeholder="Total Night" required minlength="10" maxlength="30">
        </div>

        <div id="btnRegister">
            <input type="submit" value="Book">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas\resources\views/components/pembayaran.blade.php ENDPATH**/ ?>