<style>
    .footer{
        clear: both;
        margin-top:100px;
        background-color:darkslategray ;
        color:white;
        font-family: 'Quicksand', sans-serif;
        font-weight: bold;
        font-size: 20px;
        padding-top: 20px;
        padding-bottom: 20px;
    }
</style>
<div class="footer">
    <center>© Copyright HotelInn<br> Contact : 0812696969 <br> - Best choices to sleep and relax - </center>
</div>
<?php /**PATH C:\xampp\htdocs\Proyek\resources\views/includes/footer.blade.php ENDPATH**/ ?>