<?php $__env->startSection('content'); ?>
    <style>
        .container {
            width:auto;
            height:auto;
            background-color: lightyellow;
        }
    </style>
    <!-- isset ini untuk melakukan pengecekan apakah isi dari $angka ada isinya, supaya tidak error ketika isi dari $angka adalah kosong-->

    <script>
        //Javascript biasa, ini untuk mengambil isi dari komponen select dengan id "Selector"
        function tampilkan() {
            var selected = document.getElementById("selector").selectedIndex;

            var berat = document.getElementById("berat").value;
            if(berat>0){
                if(selected=="1"){
                var hasil = berat*35.274;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="2"){
                var hasil = berat*2.20462;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="3"){
                var hasil = berat*0.0283495;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="4"){
                var hasil = berat*0.453592;
                document.getElementById("hasil").value=hasil;
            }
            }
            else{
                alert("berat tidak boleh negatif")
            }

        }
    </script>

    <div class="container">
        <h1>Calculator berat</h1>
        <br><br>
        Masukkan berat asal :<br>
        <input type="number" id="berat"><br>
        Konversi dari-ke<br>
        <select name="" id="selector" onchange="tampilkan()">
            <option value="">Pilih konversi:</option>
            <option value="1">kilogram - ounce</option>
            <option value="2">kilogram - pound</option>
            <option value="3">ounce - kilogram</option>
            <option value="4">pound - kilogram</option>
        </select><br>
        Hasil :<br>
        <input type="text" id="hasil" name="hasila" readonly>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tutorweek1\tutor1\resources\views/components/body3.blade.php ENDPATH**/ ?>