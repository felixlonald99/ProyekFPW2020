<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        .container{
            position:absolute;
            width: 100%;
            height: 100%;
            background-image: url("images/register.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }
        #registerBox{
            height:90%;
            width:50%;
            position:absolute;
            left:25%;
            top:5%;
            font-family: 'Roboto', sans-serif;
            background-color: white;
            opacity: 0.8;
        }
        .registerBoxTransparent{
            height:90%;
            width:50%;
            position:absolute;
            left:25%;
            font-family: 'Roboto', sans-serif;
            top:5%;
        }
        #derawanAdventures{
            position:absolute;
            width: 100%;
            top:5%;
            font-size:40px;
            font-weight:bold;
            cursor: pointer;
            -webkit-transition: 0.5s ease;
        }
        #logo1{
            position: absolute;
            left:26%;
            color:tomato;
        }
        #logo2{
            position: absolute;
            left:49%;
            color:green;
        }
        #derawanAdventures:hover{
            text-shadow: 0px -2px 0px #000000, 0 0 0px rgba(255, 255, 255, 0.8), 0 -4px 15px rgba(255, 255, 255, 0.5);
        }
        input[type=text], select {
            width: 100%;
            padding: 10px 10px;
            border: 2px solid #ccc;
            border-radius: 4px;
            font-size:18px;
            opacity: 1;
        }
        input[type=password], select {
            width: 100%;
            padding: 10px 10px;
            border: 2px solid #ccc;
            border-radius: 4px;
            font-size:18px;
        }
        input[type=submit] {
            width: 100%;
            background-color: tomato;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size:20px;
            transition:0.5s;
        }
        input:hover[type=submit]{
            cursor:pointer;
            background-color: green;
        }
        #fullnameInput{
            position:absolute;
            left:30%;
            top:20%;
        }
        #mobileNumberInput{
            position:absolute;
            left:30%;
            top:30%;
        }
        #emailInput{
            position:absolute;
            left:30%;
            top:40%;
        }
        #passwordInput{
            position:absolute;
            left:30%;
            top:50%;
        }
        #confirmPasswordInput{
            position:absolute;
            left:30%;
            top:60%;
        }
        #btnRegister{
            position:absolute;
            left:41%;
            top:75%;
        }
        #loginText{
            position:absolute;
            left:33%;
            top:90%;
            font-size:20px;
        }
        .errors{
            position:absolute;
            top:5%;
            left:5%;
        }
    </style>

    <script>
        function loginPage(){
            window.location.href = "http://localhost:8000/login";
        }
    </script>

</head>
<body style="margin:0px;">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&family=Roboto:wght@500&display=swap" rel="stylesheet">

<div class="container"></div>
<div id="registerBox"></div>
<div class="registerBoxTransparent">
    <div id="derawanAdventures">
        <div id="logo1">Derawan</div>
        <div id="logo2">Adventures</div>
    </div>

    <form method = "POST" action="<?php echo e(url('/prosesRegister')); ?>">
        <?php echo csrf_field(); ?>

        <div id="fullnameInput">
            <input type="text" name="fullname" placeholder="Full Name"  >
        </div>
        <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color:red; font-weight:bold;position: absolute;left:70%;top:20.5%;font-size:14px"> <<< <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div id="emailInput">
            <input type="text" name="email" placeholder="Email"  >
        </div>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color:red; font-weight:bold;position:absolute;left:70%;top:41%;font-size:14px" > <<< <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div id="mobileNumberInput">
            <input type="text" name="mobilenumber" placeholder="Mobile Number"   >
        </div>
        <?php $__errorArgs = ['mobilenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color:red; font-weight:bold;position:absolute;left:70%;top:32%;font-size:14px" > <<< <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div id="passwordInput">
            <input type="password" name="password" placeholder="Password"  >
        </div>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color:red; font-weight:bold;position:absolute;left:70%;top:51%;font-size:14px" > <<< <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div id="confirmPasswordInput">
            <input type="password" name="password_confirmation" placeholder="Confirm Password"  >
        </div>

        <div id="btnRegister">
            <input type="submit" value="Register">
        </div>

        <?php if(isset($errorEmail)): ?>
        <div style="color:red; font-weight:bold;position:absolute;left:70%;top:41%;font-size:14px" > <<< <?php echo e($errorEmail); ?></div>
        <?php endif; ?>

        <?php if(isset($errorNoHP)): ?>
        <div style="color:red; font-weight:bold;position:absolute;left:70%;top:32%;font-size:14px" > <<< <?php echo e($errorNoHP); ?></div>
        <?php endif; ?>
    </form>


    <div id="loginText">Already have an ID? <a href="http://localhost:8000/login">Login</a></div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Tugas\resources\views/components/register.blade.php ENDPATH**/ ?>