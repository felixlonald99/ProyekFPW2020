<style>
    .header{
        height: 200px;
        background-color:cyan;
        color:white;
        line-height: 150px;
    }
    #logostts{
        position: absolute;
        width: 100px;
        height: 100px;
        background-image: url("images/logo.png");
    }
    #button1{

    }
</style>
<div class="header">
    <div id="logostts"></div>
    <center><h1 style="color: black;">Prak Week 1</h1></center>
    <a href="http://127.0.0.1:8000/panjang"><button style="position:absolute;left:80%;top:10%">Panjang</button></a>
    <a href="http://127.0.0.1:8000/berat"><button style="position:absolute;left:85%;top:10%">Berat</button></a>
    <a href="http://127.0.0.1:8000/suhu"><button style="position:absolute;left:90%;top:10%">Suhu</button></a>
</div>
<?php /**PATH C:\xampp\htdocs\tutorweek1\tutor1\resources\views/includes/header.blade.php ENDPATH**/ ?>