<style>
    .footer{
        background-color:lightskyblue ;
        color:black;
    }
</style>
<div class="footer">
    <center>© FPW 2020<br>217116594</center>
</div>
<?php /**PATH C:\xampp\htdocs\tutorweek1\tutor1\resources\views/includes/footer.blade.php ENDPATH**/ ?>