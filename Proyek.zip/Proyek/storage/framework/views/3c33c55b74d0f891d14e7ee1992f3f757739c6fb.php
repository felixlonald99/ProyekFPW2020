<style>
    .footer{
        clear: both;
        margin-top:100px;
        background-color:darkslategray ;
        color:white;
        font-family: 'Quicksand', sans-serif;
        font-weight: bold;
        font-size: 20px;
        padding-top: 20px;
        padding-bottom: 20px;
    }
</style>
<div class="footer">
    <center>© Copyright Derawan Adventures<br> Contact : 0812696969 <br> - Adventures on Derawan will always in your memory - </center>
</div>
<?php /**PATH C:\xampp\htdocs\Tugas\resources\views/includes/footer.blade.php ENDPATH**/ ?>