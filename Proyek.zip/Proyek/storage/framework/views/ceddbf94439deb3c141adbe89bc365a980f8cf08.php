<?php $__env->startSection('content'); ?>
    <style>
        .container {
            width:auto;
            height:auto;
            background-color: lightyellow;
        }
    </style>
    <!-- isset ini untuk melakukan pengecekan apakah isi dari $angka ada isinya, supaya tidak error ketika isi dari $angka adalah kosong-->

    <script>
        //Javascript biasa, ini untuk mengambil isi dari komponen select dengan id "Selector"
        function tampilkan() {
            var selected = document.getElementById("selector").selectedIndex;

            var panjang = document.getElementById("panjang").value;
            if(panjang>0){
                if(selected=="1"){
                var hasil = panjang*1.09361;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="2"){
                var hasil = panjang*3.28084;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="3"){
                var hasil = panjang*0.393701;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="4"){
                var hasil = panjang*0.9144;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="5"){
                var hasil = panjang*0.3048;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="6"){
                var hasil = panjang*2.54;
                document.getElementById("hasil").value=hasil;
            }
            }
            else{
                alert("Panjang tidak boleh negatif")
            }

        }
    </script>

    <div class="container">
        <h1>Calculator panjang</h1>
        <br><br>
        Masukkan panjang asal :<br>
        <input type="number" id="panjang"><br>
        Konversi dari-ke<br>
        <select name="" id="selector" onchange="tampilkan()">
            <option value="">Pilih konversi:</option>
            <option value="1">meter - yard</option>
            <option value="2">meter - foot</option>
            <option value="3">centimeter - inch</option>
            <option value="4">yard - meter</option>
            <option value="5">foot - meter</option>
            <option value="6">inch - centimeter</option>
        </select><br>
        Hasil :<br>
        <input type="text" id="hasil" name="hasila" readonly>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas\resources\views/components/body2.blade.php ENDPATH**/ ?>