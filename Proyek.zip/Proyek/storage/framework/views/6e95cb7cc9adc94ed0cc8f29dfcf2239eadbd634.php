<style>
    .header{
        background-color:#00008B;
        color:white;
    }
</style>
<div class="header">
    <center>Ini adalah header saya :)</center>
</div><?php /**PATH F:\Kris\Kuliah Infor\Astep\Ganjil 2020\FPW\m1\tutor\tutor1\resources\views/includes/header.blade.php ENDPATH**/ ?>