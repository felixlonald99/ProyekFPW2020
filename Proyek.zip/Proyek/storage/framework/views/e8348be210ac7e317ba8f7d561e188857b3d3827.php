<?php $__env->startSection('content'); ?>
    <style>
        .container {
            width:auto;
            height:auto;
            background-color: lightyellow;
        }
    </style>
    <!-- isset ini untuk melakukan pengecekan apakah isi dari $angka ada isinya, supaya tidak error ketika isi dari $angka adalah kosong-->

    <script>
        //Javascript biasa, ini untuk mengambil isi dari komponen select dengan id "Selector"
        function tampilkan() {
            var selected = document.getElementById("selector").selectedIndex;

            var suhu = document.getElementById("suhu").value;

                if(selected=="1"){
                var hasil = suhu*9/5+32;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="2"){
                var hasil = suhu*9/4;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="3"){
                var hasil = suhu*5/4;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="4"){
                var hasil = suhu*(4/5);
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="5"){
                var hasil = (suhu-32)*5/9;
                document.getElementById("hasil").value=hasil;
            }
            else if(selected=="6"){
                var hasil = (suhu-32)*4/9;
                document.getElementById("hasil").value=hasil;

            }

        }
    </script>

    <div class="container">
        <h1>Calculator suhu</h1>
        <br><br>
        Masukkan suhu asal :<br>
        <input type="number" id="suhu"><br>
        Konversi dari-ke<br>
        <select name="" id="selector" onchange="tampilkan()">
            <option value="">Pilih konversi:</option>
            <option value="1">celcius - farenheit</option>
            <option value="2">reamur - farenheit</option>
            <option value="3">reamur - celcius</option>
            <option value="4">celcius - reamur</option>
            <option value="5">farenheit - celcius</option>
            <option value="6">farenheit - reamur</option>
        </select><br>
        Hasil :<br>
        <input type="text" id="hasil" name="hasila" readonly>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tutorweek1\tutor1\resources\views/components/body4.blade.php ENDPATH**/ ?>